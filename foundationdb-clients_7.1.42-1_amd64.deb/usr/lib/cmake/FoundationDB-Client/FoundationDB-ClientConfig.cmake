include("${CMAKE_CURRENT_LIST_DIR}/FoundationDB-Client.cmake")
