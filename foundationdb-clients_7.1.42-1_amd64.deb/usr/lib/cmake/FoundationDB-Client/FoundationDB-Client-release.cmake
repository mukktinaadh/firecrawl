#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "fdb_c" for configuration "Release"
set_property(TARGET fdb_c APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(fdb_c PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/usr/lib/libfdb_c.so"
  IMPORTED_SONAME_RELEASE "libfdb_c.so"
  )

list(APPEND _cmake_import_check_targets fdb_c )
list(APPEND _cmake_import_check_files_for_fdb_c "${_IMPORT_PREFIX}/usr/lib/libfdb_c.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
